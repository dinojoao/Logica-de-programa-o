﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculadoraQNãoCalcula
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("1");
        }

        private void btnDivisao_Click(object sender, EventArgs e)
        {
            MessageBox.Show("/");
        }

        private void btnZero_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Zero");
        }

        private void btnPonto_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Ponto");

        }

        private void BtnIgual_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Igual");
        }

        private void btnMais_Click(object sender, EventArgs e)
        {
            MessageBox.Show("+");
        }

        private void btnMenos_Click(object sender, EventArgs e)
        {
            MessageBox.Show("-");        }
    }
}
