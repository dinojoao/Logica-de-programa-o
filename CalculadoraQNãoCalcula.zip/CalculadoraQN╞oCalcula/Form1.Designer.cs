﻿namespace CalculadoraQNãoCalcula
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn1 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btnSete = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btnZero = new System.Windows.Forms.Button();
            this.btnPonto = new System.Windows.Forms.Button();
            this.BtnIgual = new System.Windows.Forms.Button();
            this.btnMais = new System.Windows.Forms.Button();
            this.btnMenos = new System.Windows.Forms.Button();
            this.btnVezes = new System.Windows.Forms.Button();
            this.btnDivisao = new System.Windows.Forms.Button();
            this.txtTexto = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn1
            // 
            this.btn1.BackgroundImage = global::CalculadoraQNãoCalcula.Properties.Resources.images__1_;
            this.btn1.Font = new System.Drawing.Font("MV Boli", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn1.Location = new System.Drawing.Point(12, 300);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(84, 81);
            this.btn1.TabIndex = 0;
            this.btn1.Text = "1";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // btn2
            // 
            this.btn2.BackgroundImage = global::CalculadoraQNãoCalcula.Properties.Resources.images__1_;
            this.btn2.Font = new System.Drawing.Font("MV Boli", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn2.Location = new System.Drawing.Point(102, 300);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(84, 81);
            this.btn2.TabIndex = 1;
            this.btn2.Text = "2";
            this.btn2.UseVisualStyleBackColor = true;
            // 
            // btn3
            // 
            this.btn3.BackgroundImage = global::CalculadoraQNãoCalcula.Properties.Resources.images__1_;
            this.btn3.Font = new System.Drawing.Font("MV Boli", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn3.Location = new System.Drawing.Point(192, 300);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(84, 81);
            this.btn3.TabIndex = 2;
            this.btn3.Text = "3";
            this.btn3.UseVisualStyleBackColor = true;
            // 
            // btn4
            // 
            this.btn4.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn4.BackgroundImage = global::CalculadoraQNãoCalcula.Properties.Resources.images__1_;
            this.btn4.Font = new System.Drawing.Font("MV Boli", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn4.Location = new System.Drawing.Point(12, 213);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(84, 81);
            this.btn4.TabIndex = 3;
            this.btn4.Text = "4";
            this.btn4.UseVisualStyleBackColor = false;
            // 
            // btn5
            // 
            this.btn5.BackgroundImage = global::CalculadoraQNãoCalcula.Properties.Resources.images__1_;
            this.btn5.Font = new System.Drawing.Font("MV Boli", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn5.Location = new System.Drawing.Point(102, 213);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(84, 81);
            this.btn5.TabIndex = 4;
            this.btn5.Text = "5";
            this.btn5.UseVisualStyleBackColor = true;
            // 
            // btn6
            // 
            this.btn6.BackgroundImage = global::CalculadoraQNãoCalcula.Properties.Resources.images__1_;
            this.btn6.Font = new System.Drawing.Font("MV Boli", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn6.Location = new System.Drawing.Point(192, 213);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(84, 81);
            this.btn6.TabIndex = 5;
            this.btn6.Text = "6";
            this.btn6.UseVisualStyleBackColor = true;
            // 
            // btnSete
            // 
            this.btnSete.BackgroundImage = global::CalculadoraQNãoCalcula.Properties.Resources.images__1_;
            this.btnSete.Font = new System.Drawing.Font("MV Boli", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSete.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnSete.Location = new System.Drawing.Point(12, 126);
            this.btnSete.Name = "btnSete";
            this.btnSete.Size = new System.Drawing.Size(84, 81);
            this.btnSete.TabIndex = 6;
            this.btnSete.Text = "7";
            this.btnSete.UseVisualStyleBackColor = true;
            // 
            // btn8
            // 
            this.btn8.BackgroundImage = global::CalculadoraQNãoCalcula.Properties.Resources.images__1_;
            this.btn8.Font = new System.Drawing.Font("MV Boli", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn8.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn8.Location = new System.Drawing.Point(102, 126);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(84, 81);
            this.btn8.TabIndex = 7;
            this.btn8.Text = "8";
            this.btn8.UseVisualStyleBackColor = true;
            // 
            // btn9
            // 
            this.btn9.BackgroundImage = global::CalculadoraQNãoCalcula.Properties.Resources.images__1_;
            this.btn9.Font = new System.Drawing.Font("MV Boli", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn9.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn9.Location = new System.Drawing.Point(192, 126);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(84, 81);
            this.btn9.TabIndex = 8;
            this.btn9.Text = "9";
            this.btn9.UseVisualStyleBackColor = true;
            // 
            // btnZero
            // 
            this.btnZero.BackgroundImage = global::CalculadoraQNãoCalcula.Properties.Resources.images__1_;
            this.btnZero.Font = new System.Drawing.Font("MV Boli", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnZero.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnZero.Location = new System.Drawing.Point(12, 393);
            this.btnZero.Name = "btnZero";
            this.btnZero.Size = new System.Drawing.Size(84, 81);
            this.btnZero.TabIndex = 9;
            this.btnZero.Text = "0";
            this.btnZero.UseVisualStyleBackColor = true;
            this.btnZero.Click += new System.EventHandler(this.btnZero_Click);
            // 
            // btnPonto
            // 
            this.btnPonto.BackgroundImage = global::CalculadoraQNãoCalcula.Properties.Resources.images__1_;
            this.btnPonto.Font = new System.Drawing.Font("MV Boli", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPonto.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnPonto.Location = new System.Drawing.Point(102, 393);
            this.btnPonto.Name = "btnPonto";
            this.btnPonto.Size = new System.Drawing.Size(84, 81);
            this.btnPonto.TabIndex = 10;
            this.btnPonto.Text = ".";
            this.btnPonto.UseVisualStyleBackColor = true;
            this.btnPonto.Click += new System.EventHandler(this.btnPonto_Click);
            // 
            // BtnIgual
            // 
            this.BtnIgual.BackgroundImage = global::CalculadoraQNãoCalcula.Properties.Resources.images__1_;
            this.BtnIgual.Font = new System.Drawing.Font("MV Boli", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnIgual.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.BtnIgual.Location = new System.Drawing.Point(192, 393);
            this.BtnIgual.Name = "BtnIgual";
            this.BtnIgual.Size = new System.Drawing.Size(84, 81);
            this.BtnIgual.TabIndex = 11;
            this.BtnIgual.Text = "=";
            this.BtnIgual.UseVisualStyleBackColor = true;
            this.BtnIgual.Click += new System.EventHandler(this.BtnIgual_Click);
            // 
            // btnMais
            // 
            this.btnMais.BackgroundImage = global::CalculadoraQNãoCalcula.Properties.Resources.images__1_;
            this.btnMais.Font = new System.Drawing.Font("MV Boli", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMais.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnMais.Location = new System.Drawing.Point(282, 358);
            this.btnMais.Name = "btnMais";
            this.btnMais.Size = new System.Drawing.Size(84, 116);
            this.btnMais.TabIndex = 12;
            this.btnMais.Text = "+";
            this.btnMais.UseVisualStyleBackColor = true;
            this.btnMais.Click += new System.EventHandler(this.btnMais_Click);
            // 
            // btnMenos
            // 
            this.btnMenos.BackgroundImage = global::CalculadoraQNãoCalcula.Properties.Resources.images__1_;
            this.btnMenos.Font = new System.Drawing.Font("MV Boli", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMenos.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnMenos.Location = new System.Drawing.Point(282, 300);
            this.btnMenos.Name = "btnMenos";
            this.btnMenos.Size = new System.Drawing.Size(84, 52);
            this.btnMenos.TabIndex = 13;
            this.btnMenos.Text = "-";
            this.btnMenos.UseVisualStyleBackColor = true;
            this.btnMenos.Click += new System.EventHandler(this.btnMenos_Click);
            // 
            // btnVezes
            // 
            this.btnVezes.BackgroundImage = global::CalculadoraQNãoCalcula.Properties.Resources.images__1_;
            this.btnVezes.Font = new System.Drawing.Font("MV Boli", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVezes.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnVezes.Location = new System.Drawing.Point(280, 213);
            this.btnVezes.Name = "btnVezes";
            this.btnVezes.Size = new System.Drawing.Size(84, 81);
            this.btnVezes.TabIndex = 14;
            this.btnVezes.Text = "x";
            this.btnVezes.UseVisualStyleBackColor = true;
            // 
            // btnDivisao
            // 
            this.btnDivisao.BackgroundImage = global::CalculadoraQNãoCalcula.Properties.Resources.images__1_;
            this.btnDivisao.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnDivisao.FlatAppearance.BorderSize = 5;
            this.btnDivisao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDivisao.Font = new System.Drawing.Font("MV Boli", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDivisao.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnDivisao.Location = new System.Drawing.Point(282, 126);
            this.btnDivisao.Name = "btnDivisao";
            this.btnDivisao.Size = new System.Drawing.Size(84, 81);
            this.btnDivisao.TabIndex = 15;
            this.btnDivisao.Text = "÷";
            this.btnDivisao.UseVisualStyleBackColor = true;
            this.btnDivisao.Click += new System.EventHandler(this.btnDivisao_Click);
            // 
            // txtTexto
            // 
            this.txtTexto.BackColor = System.Drawing.SystemColors.InfoText;
            this.txtTexto.ForeColor = System.Drawing.Color.White;
            this.txtTexto.Location = new System.Drawing.Point(12, 28);
            this.txtTexto.Multiline = true;
            this.txtTexto.Name = "txtTexto";
            this.txtTexto.Size = new System.Drawing.Size(352, 55);
            this.txtTexto.TabIndex = 16;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BackgroundImage = global::CalculadoraQNãoCalcula.Properties.Resources.blue_sea_sea_blue_sky_white_clouds_ocean_scenery;
            this.ClientSize = new System.Drawing.Size(376, 486);
            this.Controls.Add(this.txtTexto);
            this.Controls.Add(this.btnDivisao);
            this.Controls.Add(this.btnVezes);
            this.Controls.Add(this.btnMenos);
            this.Controls.Add(this.btnMais);
            this.Controls.Add(this.BtnIgual);
            this.Controls.Add(this.btnPonto);
            this.Controls.Add(this.btnZero);
            this.Controls.Add(this.btn9);
            this.Controls.Add(this.btn8);
            this.Controls.Add(this.btnSete);
            this.Controls.Add(this.btn6);
            this.Controls.Add(this.btn5);
            this.Controls.Add(this.btn4);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btn1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btnSete;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btnZero;
        private System.Windows.Forms.Button btnPonto;
        private System.Windows.Forms.Button BtnIgual;
        private System.Windows.Forms.Button btnMais;
        private System.Windows.Forms.Button btnMenos;
        private System.Windows.Forms.Button btnVezes;
        private System.Windows.Forms.Button btnDivisao;
        private System.Windows.Forms.TextBox txtTexto;
    }
}

